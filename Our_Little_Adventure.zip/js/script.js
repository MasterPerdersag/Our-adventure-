
let sceneIndex = 0;
const scenes = [
    {
        en: "The journey begins under the moonlight...",
        fa: "سفر ما زیر نور ماه شروع می‌شود..."
    },
    {
        en: "In Istanbul, the streets whispered new stories.",
        fa: "در استانبول، خیابان‌ها داستان‌های جدیدی را زمزمه می‌کردند."
    },
    {
        en: "In Tiflis, you called me Pinky Donkey and smiled like always.",
        fa: "در تفلیس، مرا پینکی دانکی صدا زدی و مثل همیشه لبخند زدی."
    },
    {
        en: "And in Dresden, I was still your Baby 2.",
        fa: "و در درسدن، من هنوز بیبی ۲ تو بودم."
    }
];

function nextScene() {
    sceneIndex++;
    if (sceneIndex < scenes.length) {
        document.getElementById("englishText").innerText = scenes[sceneIndex].en;
        document.getElementById("farsiText").innerText = scenes[sceneIndex].fa;
    } else {
        document.getElementById("scene").innerHTML = "<h2>Happy Birthday, Pedersag!</h2><p>From your Bärchen.</p>";
    }
}
